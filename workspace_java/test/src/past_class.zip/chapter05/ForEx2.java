package chapter05;

public class ForEx2 {

	public static void main(String[] args) {
		
		int sum = 0;
		
		for (int i=1; i<=100; i++) {
			sum += i;		// sum = sum + i
		}
		
		System.out.println("합계 : " + sum);
		
		
//		sum = 0;
//		// for문 
//		sum += 1; // sum = 0+1
//		sum += 2; // sum = 1+2
//		sum += 3; // sum = 3+3
//		sum += 4; // sum = 6+4
//		....
//		sum += 100; // sum = 4950+100
		
		
		
		
	}

}
