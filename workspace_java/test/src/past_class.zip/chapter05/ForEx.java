package chapter05;

public class ForEx {

	public static void main(String[] args) {
		for (int i=0; i<10; i++) {
			System.out.println("i = " + i);
		}
		
	}

}
