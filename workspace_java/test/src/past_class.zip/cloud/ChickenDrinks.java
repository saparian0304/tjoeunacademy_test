package cloud;

public class ChickenDrinks {
	public static void main (String[] args) {
	    System.out.println("치킨엔 " + args[0] + "가 제맛이지~");
	  }
}
