package cloud;

public class KimBob {
	public static void main(String[] args) {
		System.out.println(args[0] + " 김밥~");
		System.out.println(args[1] + " 김밥~");
	}
}