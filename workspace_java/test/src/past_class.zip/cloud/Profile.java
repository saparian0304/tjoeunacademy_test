package cloud;

public class Profile {
	public static void main(String[] args) {
		// 1. 이름을 출력하시오.
		String name = "홍팍";
		System.out.println("이름 : " + name);
		// 2. 나이를 출력하시오.
		int age = 35;
		System.out.println("나이 : " + age);
		// 3. 키 출력하시오.
		double height = 176.4;
		System.out.println("신장 : " + height);
		// 4. 자바 입문 여부를 출력하시오.
		boolean exp = true;
//		boolean isBegin = true;
		System.out.println("입문자입니까? " + exp);
	}
}
