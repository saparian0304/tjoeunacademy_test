package cloud;

public class Score {

	public static void main(String[] args) {
	    /* 1. 변수 생성 */
		int math, sci, eng;
		math = 96;
		sci = 88;
		eng = 76;
		
	    /* 2. 결과 출력 */
		System.out.println("수학: " + math);
		System.out.println("과학: " + sci);
		System.out.println("영어: " + eng);
	}

}
