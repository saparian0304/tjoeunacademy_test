package cloud;

public class Test {
	public static void main(String[] args) {
		String number = "22.2";
		int number2 = Integer.parseInt(number);		// number가 실수라서 에러가 발생함
	}
}
