package chapter02;

public class HelloJava {
	public static void main(String[] args) {
		//System.out.println("안녕하세요");
		/*
		 * 여기는 여러줄 주석
		 * 전부 실행이 안됨 
		 */
		// 출력문 단축키 sysout ctrl+space
		// 주석 단축키 ctrl + '/'
		System.out.println("hello");
		System.out.println("hello");
		System.out.println("hello");
		System.out.println("hello");
		
		/*
		 * hello가 출력되게 하기 위해서
		 * 2022.04.25 anjp0304
		 */
		System.out.println("hello");
	}
}
